#include "other.h"

Other::Other()
{

}

int Other::type() const
{
    return Type;
}
